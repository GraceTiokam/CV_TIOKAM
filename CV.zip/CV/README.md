CV  - Grace Cardle

Ce projet est un CV web réalisé en Responsive Design en utilisant Tailwind CSS. Il respecte les exigences du projet noté de l'ISFATES.

🔹 Technologies utilisées
- HTML5
- CSS3
- Tailwind CSS
- FontAwesome (pour les icônes)

📌 Fonctionnalités
- CV interactif et responsive
- Adaptabilité à trois tailles d'écran : mobile, tablette et desktop
- Utilisation d'une grille responsive
- Styles cohérents et normalisés

📜 Structure du projet
```
📂 CV
 ├── 📄 index.html  (Page principale du CV)
 ├── 📂 assets      (Images et icônes utilisées)
 └── 📄 README.md   (Ce fichier) 
 ```

Comment voir mon CV ?
 Option 1 : Ouvrir localement
1. Télécharger ou cloner le repository
2. Ouvrir `index.html` dans un navigateur

 Option 2 : Héberger en ligne
Le CV peut être consulté sur [GitHub Pages](https://pages.github.com/) ou tout autre service d'hébergement statique.

📩 Déploiement sur GitHub Pages
1. Aller dans l'onglet "Settings" du repository GitHub
2. Naviguer vers "Pages"
3. Sélectionner la branche contenant `index.html`
4. ouvrir avec le live server
    inspecter avec la taille 
        iPhone 14 pro max --> sm 
        iPad pro --> md

📧 Contact
- 📞 Téléphone : +33 667-412-635
- 📩 Email : ctiokam@gmail.com
- 📍 Adresse : 4, rue des Trinitaires, Metz, France

---
© 2025 Grace Cardle
